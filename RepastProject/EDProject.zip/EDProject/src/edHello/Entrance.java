package edHello;

public class Entrance {

}
