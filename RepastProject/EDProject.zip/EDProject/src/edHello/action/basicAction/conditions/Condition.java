package edHello.action.basicAction.conditions;

public class Condition {

}
