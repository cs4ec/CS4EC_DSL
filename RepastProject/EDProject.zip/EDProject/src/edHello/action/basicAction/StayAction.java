package edHello.action.basicAction;

import edHello.action.ActionFragment;

public class StayAction extends ActionFragment {
		
}
