package edHello.logNote;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class LogNote {
	
	private String projectPath = "";
	private static LogNote logInstance = null;
	
	private LogNote() {}
	
	public static LogNote GetUniqueLog() {
		if(logInstance != null) {
			return logInstance;
		}else {
			logInstance = new LogNote();
			return logInstance;
		}
	}
	
    public void SetAddress(String s) {
    	projectPath = s;
	}
    
    public String GetAddress() {
    	return projectPath;
	}
	
	public void WriteLog(String fileName, String content) {
		try { 
			System.out.println("gene file: " + projectPath + "output\\" + fileName + ".txt");
			File file = new File(projectPath + "output\\" + fileName + ".txt");
			System.out.println(file.getAbsolutePath());
			System.out.println(file.getPath());
			if(!file.exists()){
				file.createNewFile();
			}
			FileWriter fileWriter = new FileWriter(file.getAbsoluteFile(),true);
			BufferedWriter bw = new BufferedWriter(fileWriter);
			bw.write(content + "\n");
			bw.close();
			System.out.println("finish");
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	}

}
