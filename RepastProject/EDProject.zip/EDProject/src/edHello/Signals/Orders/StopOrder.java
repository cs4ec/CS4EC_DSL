package edHello.Signals.Orders;

public class StopOrder extends Order{

}
