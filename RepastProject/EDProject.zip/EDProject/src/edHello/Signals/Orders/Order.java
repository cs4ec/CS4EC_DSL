package edHello.Signals.Orders;

public class Order {

}
