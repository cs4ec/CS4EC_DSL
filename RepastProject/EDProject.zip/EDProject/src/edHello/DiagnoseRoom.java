package edHello;

public class DiagnoseRoom {

}
